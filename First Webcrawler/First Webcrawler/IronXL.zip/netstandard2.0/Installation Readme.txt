Add IronBarCode.dll as an reference to your .Net Core or Standard project.

Please add a reference to System.Drawing.Common in your project to enable barcode rendering capabilities.
- https://www.nuget.org/packages/System.Drawing.Common/